//Coding Journal: Mon Feb 10 to Thurs Feb 13

// No comments/labels for individual days' work -- just spread out throughout the week.

import SwiftUI

enum Car_Type: String, CaseIterable {
    case sedan
    case SUV
    case convertible
    case van
    case hatchback
    case none = "Select a car type"
}

enum Colors: String, CaseIterable {
    case red
    case blue
    case green
    case yellow
    case black
    case white
    case none = "Select a color"
}

enum Num_Defects: String, CaseIterable {
    case none
    case minor
    case major
}

enum Owner_Count: String, CaseIterable {
    case one
    case two
    case three
    case four
    case moreThanFive = "Five or more owners"
}

struct StartView: View {
    
    // User input states
    @State private var make = "" //INPUT
    @State private var model = "" // INPUT
    @State private var year = "" // INPUT
    @State private var car_type: Car_Type = .none // DEFAULT -- PICKER
    @State private var color: Colors = .none // DEFAULT -- PICKER
    @State private var num_defects: Num_Defects = .none // DEFAULT -- PICKER
    @State private var owner_count: Owner_Count = .one // DEFAULT -- PICKER
    
    @FocusState private var focus: Bool //keyboard pop ups bc we need those!!!
    @State private var search_started = false // this is basically a mod of the gamestarted variable that we had.
    
    
    var body: some View {
        NavigationStack {
            VStack {
                Text("Finding Your Dream Car (woohoo!!)")
                    .padding()
                
                TextField("Make", text: $make)
                    .padding()
                
                TextField("Model", text: $model)
                    .padding()
                
                TextField("Year", text: $year)
                    .padding()
                
                Picker("Car Type", selection: $car_type) {
                    ForEach(Car_Type.allCases, id: \..self) { type in
                        Text(type.rawValue).tag(type)
                    }
                }
                .pickerStyle(.menu)
                .padding()
                
                Picker("Car Color", selection: $color) {
                    ForEach(Colors.allCases, id: \..self) { color in
                        Text(color.rawValue).tag(color)
                    }
                }
                .pickerStyle(.menu)
                .padding()
                
                Picker("Maximum Defects", selection: $num_defects) {
                    ForEach(Num_Defects.allCases, id: \..self) { defect in
                        Text(defect.rawValue).tag(defect)
                    }
                }
                .pickerStyle(.segmented)
                .padding()
                
                Picker("Number of Previous Owners", selection: $owner_count) {
                    ForEach(Owner_Count.allCases, id: \..self) { count in
                        Text(count.rawValue).tag(count)
                    }
                }
                .pickerStyle(.menu)
                .padding()
                
                Button("Start Search") {
                    focus = false // ditch the keyboard
                    search_started.toggle() // start the search.
                }
                .buttonStyle(.borderedProminent)
                .disabled(make.isEmpty || model.isEmpty || year.isEmpty || car_type == .none || color == .none)
                .padding()
                
                Spacer()
            }
            .padding()
            .navigationTitle("CarMax App")
        }
    }
}

#Preview {
    StartView()
}
