// Coding Journal: Monday Feb 17 - Thurs, Feb 20 (feb20).

/* GOALS: Another Text-Based Project
 M-W: See below
 Th: Tests
 */

//Scenario: Design a smart home system that manages various devices and their states.
//Data Structures:
//    1.    Enum `DeviceType`: LightBulb, Thermostat, SecurityCamera, SmartLock (feb17)
//    2.    Struct `Device`: id, name, type, isOn (feb17)
//    3.    Class `SmartHome`: devices, rooms (feb17)
//Functions:
//    1.    func addDevice(device: Device) -> Void (feb17)
//    2.    func removeDevice(id: String) -> Bool (feb17)
//    3.    func toggleDevice(id: String) -> Bool (feb18)
//    4.    func getDevicesByType(type: DeviceType) -> Device (feb18)
//    5.    func getEnergyConsumption() -> Double (feb19)

// pulled the above from ChatGPT for a little bit of inspiration

// Unique functions/new features
//      inout
//      guard (needed a refresh)
//      filter
//      $0 functionality (also needed a refresh)

//TODAY: test the entire thing

enum DeviceType {
    case lightBulb
    case thermostat
    case securityCamera
    case smartLock
}

struct Device {
    let id: String
    let name: String
    let type: DeviceType
    var isOn: Bool
    var energyPerHour: Double //added feb19
    var averageUsePerDay: Double //added feb19
    
    init(id: String, name: String, type: DeviceType, isOn: Bool, energyPerHour: Double, avgUsePerDay: Double) { //added feb19
        self.id = id
        self.name = name
        self.type = type
        self.isOn = isOn
        self.energyPerHour = energyPerHour
        self.averageUsePerDay = avgUsePerDay
    }
}

class SmartHome {
    var devices: [Device] = []
    var rooms: [String: [Device]] = [:]
    
    func addDevice(device: Device) {
        self.devices.append(device)
    }
    
    func removeDevice(id: String) -> Bool {
        guard let index = devices.firstIndex(where: { $0.id == id }) //reminder of guard function: make sure that this exists in the device list at all.
        
        else {
            return false
        }
        
        devices.remove(at: index)
        return true
    }
}

//feb18: added
func toggleDevice(id: String, in smartHome: inout SmartHome) -> Bool { //inout = same as a C++ pass by reference
    guard let index = smartHome.devices.firstIndex(where: { $0.id == id })
    else {
        return false
    }
    
    smartHome.devices[index].isOn = !smartHome.devices[index].isOn
    return true
}

//feb18: added
func getDevicesByType(type: DeviceType, in smartHome: SmartHome) -> [Device] {
    return smartHome.devices.filter({ $0.type == type }) //reminder of filter: basically look through the whole array and get everything by the type
}

//feb18: added
func print_clean(smartHome: SmartHome)
{
    for device in smartHome.devices
    {
        print("SmartHome: \n\(device.id): \(device.name), \(device.type), \(device.isOn ? "On" : "Off"))");
    }
}

//feb19: added
func getEnergyConsumption(smartHome: SmartHome, time: Double) -> Double
{
    var totalEnergy: Double = 0
    
    for device in smartHome.devices
    {
        if(device.isOn)
        {
            let energyTaken: Double = device.energyPerHour * time
            
            totalEnergy += energyTaken
        }
    }
    
    return totalEnergy
}

//feb19 added
func getTotalDailyConsumption(smartHome: SmartHome) -> Double
{
    return getEnergyConsumption(smartHome: smartHome, time: 24)
}

//feb19 added
func getTotalWeeklyConsumption(smartHome: SmartHome) -> Double
{
    return getEnergyConsumption(smartHome: smartHome, time: 168)
}

//feb19 added
func consumptionOverTime(smartHome: SmartHome, days: Double) -> Double{
    return getTotalDailyConsumption(smartHome: smartHome) * days
}

// Create a SmartHome instance
var myHome = SmartHome()

// Test addDevice
let livingRoomLight = Device(id: "1", name: "Living Room Light", type: .lightBulb, isOn: false, energyPerHour: 0.06, avgUsePerDay: 5.0)
let kitchenLight = Device(id: "2", name: "Kitchen Light", type: .lightBulb, isOn: false, energyPerHour: 0.05, avgUsePerDay: 3.0)
let thermostat = Device(id: "3", name: "Thermostat", type: .thermostat, isOn: true, energyPerHour: 1.5, avgUsePerDay: 24.0)

myHome.addDevice(device: livingRoomLight)
myHome.addDevice(device: kitchenLight)
myHome.addDevice(device: thermostat)

print("Devices after adding:")
print_clean(smartHome: myHome)

// Test removeDevice
let removed = myHome.removeDevice(id: "2")
print("\nRemoved Kitchen Light: \(removed)")
print("Devices after removing Kitchen Light:")
print_clean(smartHome: myHome)

// Test toggleDevice
let toggled = toggleDevice(id: "1", in: &myHome)
print("\nToggled Living Room Light: \(toggled)")
print("Devices after toggling:")
print_clean(smartHome: myHome)

// Test getDevicesByType
let lightBulbs = getDevicesByType(type: .lightBulb, in: myHome)
print("\nLight bulbs in the home:")
for light in lightBulbs {
    print("\(light.name)")
}

// Test energy consumption calculations
let hourlyConsumption = getEnergyConsumption(smartHome: myHome, time: 1)
print("\nHourly energy consumption: \(hourlyConsumption) kWh")

let dailyConsumption = getTotalDailyConsumption(smartHome: myHome)
print("Daily energy consumption: \(dailyConsumption) kWh")

let weeklyConsumption = getTotalWeeklyConsumption(smartHome: myHome)
print("Weekly energy consumption: \(weeklyConsumption) kWh")

let monthlyConsumption = consumptionOverTime(smartHome: myHome, days: 30)
print("Monthly energy consumption: \(monthlyConsumption) kWh")

