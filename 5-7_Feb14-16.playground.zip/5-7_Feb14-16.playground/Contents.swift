// Coding Journal: Friday Feb 14 to Sunday Feb 16

// Goal for Friday and weekend -- finish up another basic project

// F: define the data structures and 2 functions (addTask and deleteTask, not labeled)
// Sa: define the last three functions (all other functions)
// ***** Su: tests and debug

//Define an enum for task priority (Low, Medium, High).
//Create a class for a Task, containing an ID, title, priority, and status.
//Make a class TaskManager, responsible for handling a list of tasks.
//Implement 5 key functions in TaskManager:
//addTask(title:priority:)
//markTaskAsComplete(id:)
//deleteTask(id:)
//listTasks()
//listPendingTasks()


enum Priority {
    case low
    case medium
    case high
}

class Task {
    var title: String
    var priority: Priority
    var status: Bool
    
    init(title: String, priority: Priority, status: Bool) {
        self.title = title
        self.priority = priority
        self.status = status
    }
    
    func markTaskAsComplete() {
        status = true
    }
}

class TaskMgr {
    var taskList: [Task] = []
    var name: String
    
    init(taskList: [Task], name: String) {
        self.taskList = taskList
        self.name = name
    }
    
    func addTask(title: String, priority: Priority) {
        let newTask = Task(title: title, priority: priority, status: false)
        taskList.append(newTask)
    }
    
    func deleteTask(title: String) {
        taskList.removeAll { $0.title == title }
    }
    
    func listTasks() -> String {
        var output: String = ""
        for task in taskList {
            output += "\(task.title), \(task.priority), \(task.status)\n"
        }
        return output
    }
    
    func completeTask(title: String) {
        if let task = taskList.first(where: { $0.title == title }) {
            task.markTaskAsComplete()
        }
    }
    
    func listPendingTasks() -> String {
        var output: String = ""
        for task in taskList {
            if !task.status {
                output += "\(task.title), \(task.priority), \(task.status)\n"
            }
        }
        return output
    }
}

// Inline tests
let manager = TaskMgr(taskList: [], name: "Test Manager")

// Test addTask
manager.addTask(title: "Buy groceries", priority: .medium)
manager.addTask(title: "Finish report", priority: .high)
manager.addTask(title: "Call mom", priority: .low)

print("After adding tasks:")
print(manager.listTasks())

// Test completeTask
manager.completeTask(title: "Buy groceries")

print("After completing 'Buy groceries':")
print(manager.listTasks())

// Test listPendingTasks
print("Pending tasks:")
print(manager.listPendingTasks())

// Test deleteTask
manager.deleteTask(title: "Call mom")

print("After deleting 'Call mom':")
print(manager.listTasks())

// Test edge cases
manager.completeTask(title: "Non-existent task") // Should not crash
manager.deleteTask(title: "Non-existent task") // Should not crash

print("Final task list:")
print(manager.listTasks())
