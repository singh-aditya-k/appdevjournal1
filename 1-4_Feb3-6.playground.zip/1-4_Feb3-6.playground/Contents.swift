// Coding Journal -- Monday Feb 3 - Thursday Feb 6


/*GOALS
 
 M: Unlabeled, set everything up for a tic tac toe logic breakdown
 T: Labeled, (feb4) -- added more functionality
 W: Labeled (feb5) -- added EVEN more functionality
 Th: Labeled (feb6) -- added tests with help of GPT for coverage
 
 */
import Foundation

struct board {
    var board: [[String]]
    init() {
        board = Array(repeating: Array(repeating: "_", count: 3), count: 3)
    }
    
    func printBoard() {
        for row in board {
            print(row)
        }
    }
    
    func isEmpty() -> Bool {
        for row in board {
            for cell in row {
                if cell == "_" {
                    return true
                }
            }
        }
        return false
    }
    
    func isValidMove(row: Int, col: Int) -> Bool {
        if row < 0 || row >= 3 || col < 0 || col >= 3 {
            return false
        }
        if board[row][col] == "_" {
            return true
        }
        return false
    }
}

struct Game {
    var currentBoard: board
    var playerTurn: String
    
    init() {
        currentBoard = board()
        playerTurn = "X"
    }
    
    mutating func move(row: Int, col: Int) -> Bool { //feb4 added: must be mutating to allow it to change itself
        if currentBoard.isValidMove(row: row, col: col) {
            currentBoard.board[row][col] = playerTurn
            if(checkWin() == playerTurn) {print("WIN: \(playerTurn)"); return true;} //feb5 modified
            switchTurn()
            return true
        }
        return false
    }
    
    mutating func switchTurn() { //feb4 added to call inside the mutating func move
        playerTurn = playerTurn == "X" ? "O" : "X" //feb4 syntax similar to if is x, then make it o, otherwise make it x
    }
    
    mutating func reset() { //feb4 added function
        currentBoard = board()
        playerTurn = "X" //let's just keep this default for right now
    }
    
    
    //feb4 added
    func checkWin() -> String? {
        for row in 0..<3 { //syntax just means that we're going from 0 until row is no longer less than 3
            if currentBoard.board[row][0] == playerTurn && currentBoard.board[row][1] == playerTurn && currentBoard.board[row][2] == playerTurn { //feb5 all row based wins
                return playerTurn
            }
            if currentBoard.board[0][row] == playerTurn && currentBoard.board[1][row] == playerTurn && currentBoard.board[2][row] == playerTurn { //feb5 all column based wins
                return playerTurn
            }
            if currentBoard.board[0][0] == playerTurn && currentBoard.board[1][1] == playerTurn && currentBoard.board[2][2] == playerTurn { //feb5 one set of diagonal wins
                return playerTurn
            }
            if currentBoard.board[2][0] == playerTurn && currentBoard.board[1][1] == playerTurn && currentBoard.board[0][2] == playerTurn { //feb5 other set of diagonal wins
                return playerTurn
            }
            //feb5 realized that these were comprehensive, no need to add too much more here.
        }
        return "NO WIN"
    }
}

//feb6 tested everything below

// Test the board struct
print("Testing board struct:")
var testBoard = board()
print("Initial board:")
testBoard.printBoard()

print("\nIs board empty? \(testBoard.isEmpty())")

print("\nTesting valid moves:")
print("Is (0,0) valid? \(testBoard.isValidMove(row: 0, col: 0))")
print("Is (3,3) valid? \(testBoard.isValidMove(row: 3, col: 3))")

// Test the Game struct
print("\nTesting Game struct:")
var game = Game()
print("Initial game board:")
game.currentBoard.printBoard()

print("\nMaking moves:")
_ = game.move(row: 0, col: 0)
_ = game.move(row: 1, col: 1)
_ = game.move(row: 0, col: 1)
_ = game.move(row: 2, col: 2)
game.currentBoard.printBoard()

print("\nTesting win condition:")
_ = game.move(row: 0, col: 2)
game.currentBoard.printBoard()

print("\nResetting game:")
game.reset()
game.currentBoard.printBoard()

print("\nTesting invalid move:")
_ = game.move(row: 0, col: 0)
let invalidMoveResult = game.move(row: 0, col: 0)
print("Invalid move result: \(invalidMoveResult)")

print("\nTesting diagonal win:")
game.reset()
_ = game.move(row: 0, col: 0) // X
_ = game.move(row: 0, col: 1) // O
_ = game.move(row: 1, col: 1) // X
_ = game.move(row: 0, col: 2) // O
_ = game.move(row: 2, col: 2) // X
game.currentBoard.printBoard()

print("\nTesting full board (no win):")
game.reset()
_ = game.move(row: 0, col: 0) // X
_ = game.move(row: 0, col: 1) // O
_ = game.move(row: 0, col: 2) // X
_ = game.move(row: 1, col: 1) // O
_ = game.move(row: 1, col: 0) // X
_ = game.move(row: 1, col: 2) // O
_ = game.move(row: 2, col: 1) // X
_ = game.move(row: 2, col: 0) // O
_ = game.move(row: 2, col: 2) // X
game.currentBoard.printBoard()
print("Is board empty? \(game.currentBoard.isEmpty())")
