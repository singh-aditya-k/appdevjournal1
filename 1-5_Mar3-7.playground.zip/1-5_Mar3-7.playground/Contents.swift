// App Dev Journal: Mon, Mar 3 - Fri, Mar 7

/*
 M: Define all data structures, init functions, func #1.
 T: complete function 2 and all helper functions
 W: complete function 3
 Th: complete function 4
 F: build tests and debug
 */

//3. Advanced Restaurant Management System
//Scenario: Develop a sophisticated restaurant management system handling dynamic pricing, inventory, and staff scheduling.
//Data Structures:
//    1.    Class `MenuItem`: id, name, basePrice, ingredients
//    2.    Struct `Inventory`: item, quantity, reorderThreshold
//    3.    Class `Employee`: id, name, role, availability
//Functions: (not all match their template exactly)
//    1.    func updateMenuPrices(strategy: PricingMultiplier) -> Void
//    2.    func optimizeStaffSchedule(date: Date) -> (Employee, TimeInterval)
//    3.    func handleOrder(items: MenuItem) throws -> (success: Bool, unavailableItems: MenuItem)
//    4.    func analyzeProfit(startDate: Date, endDate: Date) -> (revenue: Double, costs: Double, profit: Double)

import Foundation

class MenuItem {
    var id: String
    var name: String
    var basePrice: Double
    var ingredients: [String]
    var timeToPrepare: Int
    
    init(id: String, name: String, basePrice: Double, ingredients: [String], timeToPrepare: Int) {
        self.id = id
        self.name = name
        self.basePrice = basePrice
        self.ingredients = ingredients
        self.timeToPrepare = timeToPrepare
    }
}

struct Inventory {
    var item: String
    var quantity: Int
    var reorderThreshold: Int
    
    init(item: String, quantity: Int, reorderThreshold: Int) {
        self.item = item
        self.quantity = quantity
        self.reorderThreshold = reorderThreshold
    }
}

class Employee {
    var id: String
    var name: String
    var role: String
    var availability: [String]
    
    init(id: String, name: String, role: String, availability: [String]) {
        self.id = id
        self.name = name
        self.role = role
        self.availability = availability
    }
}

class Restaurant {
    var menuItems: [MenuItem] = []
    var employees: [Employee] = []
    var inventory: [Inventory] = []
    var orders: [(date: Date, items: [MenuItem])] = [] // New property to store orders
    
    init(menuItems: [MenuItem], employees: [Employee], inventory: [Inventory]) {
        self.menuItems = menuItems
        self.employees = employees
        self.inventory = inventory
    }
    
    func updateMenuPrices(strategy: Double) -> Void {
        for item in menuItems {
            item.basePrice *= strategy
        }
    }
    
    func optimizeSchedule(date: Int, expectedCustomers: Int) -> [(Employee, TimeInterval)] {
        var schedule: [(Employee, TimeInterval)] = []
        let shiftsNeeded = calculateShiftsNeeded(expectedCustomers: expectedCustomers)
        
        // Sort employees by availability for the given date
        let availableEmployees = employees.filter { $0.availability.contains(String(date)) }
        
        // Define shift times (assuming 8-hour shifts)
        let shiftTimes: [TimeInterval] = [
            TimeInterval(8 * 60 * 60),  // 8:00 AM - 4:00 PM
            TimeInterval(16 * 60 * 60)  // 4:00 PM - 12:00 AM
        ]
        
        // Assign shifts based on roles needed
        for (role, count) in shiftsNeeded {
            let employeesForRole = availableEmployees.filter { $0.role == role }
            for i in 0..<count {
                if i < employeesForRole.count {
                    schedule.append((employeesForRole[i], shiftTimes[i % 2]))
                } else {
                    print("Warning: Not enough \(role)s available for optimal staffing")
                }
            }
        }
        
        return schedule
    }
    
    private func calculateShiftsNeeded(expectedCustomers: Int) -> [String: Int] {
        // This is a simplified calculation and should be adjusted based on real-world data
        let cooksNeeded = max(1, expectedCustomers / 20)
        let serversNeeded = max(1, expectedCustomers / 15)
        let hostNeeded = expectedCustomers > 50 ? 1 : 0
        
        return [
            "Cook": cooksNeeded,
            "Server": serversNeeded,
            "Host": hostNeeded
        ]
    }
    
    enum OrderError: Error {
        case itemNotFound
        case insufficientInventory
    }
    
    func handleOrder(items: [MenuItem]) throws -> (success: Bool, unavailableItems: [MenuItem]) {
        var unavailableItems: [MenuItem] = []
        var success = true
        
        for item in items {
            guard let menuItem = menuItems.first(where: { $0.id == item.id }) else {
                unavailableItems.append(item)
                success = false
                continue
            }
            
            for ingredient in menuItem.ingredients {
                guard let inventoryItem = inventory.first(where: { $0.item == ingredient }) else {
                    throw OrderError.itemNotFound
                }
                
                if inventoryItem.quantity <= inventoryItem.reorderThreshold {
                    unavailableItems.append(item)
                    success = false
                    break
                }
            }
            
            if success {
                // Deduct ingredients from inventory
                for ingredient in menuItem.ingredients {
                    if let index = inventory.firstIndex(where: { $0.item == ingredient }) {
                        inventory[index].quantity -= 1
                    }
                }
            }
        }
        
        if success {
            // Add the order to the orders list
            orders.append((date: Date(), items: items))
        }
        
        return (success: success, unavailableItems: unavailableItems)
    }
    
    func analyzeProfit(startDate: Date, endDate: Date) -> (revenue: Double, costs: Double, profit: Double) {
        let relevantOrders = orders.filter { $0.date >= startDate && $0.date <= endDate }
        
        let revenue = relevantOrders.flatMap { $0.items }.reduce(0.0) { $0 + $1.basePrice }
        
        // Calculate costs (this is a simplified version and should be expanded based on real costs)
        let ingredientCost = Double(relevantOrders.flatMap { $0.items }.flatMap { $0.ingredients }.count) * 0.5 // Assuming $0.50 per ingredient
        let laborCost = Double(relevantOrders.count) * 5.0 // Assuming $5 labor cost per order
        let overheadCost = Double(relevantOrders.count) * 2.0 // Assuming $2 overhead cost per order
        
        let totalCosts = ingredientCost + laborCost + overheadCost
        
        let profit = revenue - totalCosts
        
        return (revenue: revenue, costs: totalCosts, profit: profit)
    }
}

// Inline tests for Restaurant class functions

// Create test data
let testMenuItem1 = MenuItem(id: "1", name: "Burger", basePrice: 10.0, ingredients: ["bun", "patty", "lettuce"], timeToPrepare: 10)
let testMenuItem2 = MenuItem(id: "2", name: "Fries", basePrice: 5.0, ingredients: ["potato"], timeToPrepare: 5)
let testEmployee1 = Employee(id: "E1", name: "John", role: "Cook", availability: ["20250314", "20250315"])
let testEmployee2 = Employee(id: "E2", name: "Jane", role: "Server", availability: ["20250314", "20250315"])
let testInventory1 = Inventory(item: "bun", quantity: 50, reorderThreshold: 10)
let testInventory2 = Inventory(item: "patty", quantity: 30, reorderThreshold: 5)
let testInventory3 = Inventory(item: "lettuce", quantity: 20, reorderThreshold: 5)
let testInventory4 = Inventory(item: "potato", quantity: 100, reorderThreshold: 20)

let restaurant = Restaurant(menuItems: [testMenuItem1, testMenuItem2],
                            employees: [testEmployee1, testEmployee2],
                            inventory: [testInventory1, testInventory2, testInventory3, testInventory4])

// Test updateMenuPrices
print("Testing updateMenuPrices:")
print("Before: Burger price = \(restaurant.menuItems[0].basePrice), Fries price = \(restaurant.menuItems[1].basePrice)")
restaurant.updateMenuPrices(strategy: 1.1)
print("After: Burger price = \(restaurant.menuItems[0].basePrice), Fries price = \(restaurant.menuItems[1].basePrice)")

// Test optimizeSchedule
print("\nTesting optimizeSchedule:")
let schedule = restaurant.optimizeSchedule(date: 20250314, expectedCustomers: 50)
print("Optimized schedule:")
for (employee, shift) in schedule {
    print("\(employee.name) (\(employee.role)): \(shift / 3600) hours")
}

// Test handleOrder
print("\nTesting handleOrder:")
do {
    let orderResult = try restaurant.handleOrder(items: [testMenuItem1, testMenuItem2])
    print("Order success: \(orderResult.success)")
    print("Unavailable items: \(orderResult.unavailableItems.map { $0.name })")
} catch {
    print("Error handling order: \(error)")
}

// Test analyzeProfit
print("\nTesting analyzeProfit:")
let startDate = Date().addingTimeInterval(-86400) // Yesterday
let endDate = Date() // Today
let profitAnalysis = restaurant.analyzeProfit(startDate: startDate, endDate: endDate)
print("Revenue: $\(profitAnalysis.revenue)")
print("Costs: $\(profitAnalysis.costs)")
print("Profit: $\(profitAnalysis.profit)")

// Print final inventory state
print("\nFinal inventory state:")
for item in restaurant.inventory {
    print("\(item.item): Quantity = \(item.quantity), Reorder Threshold = \(item.reorderThreshold)")
}
