// Coding Journal -- Mon Jan 27 - Wed Jan 29

/*
 Goals
 
 M: Unlabeled (Jan 27): set everything up
 T: Labeled (//jan28): add more functionality
 W: Labeled (//jan29): add even more functionality
 */

import Foundation
import SwiftUI

class Bill {
    var sub_total: Double
    var tip_percentage: Double
    var num_people: Int
    var tax_rate: Double
    var grand_total: Double
    
    init(sub_total: Double, tip_percentage: Double, num_people: Int, tax_rate: Double) {
        self.sub_total = sub_total
        self.num_people = num_people
        self.tax_rate = tax_rate
        self.tip_percentage = tip_percentage
        self.grand_total = 0
    }
    
    func compute_price() -> Double {
        let tipAmount = sub_total * (tip_percentage / 100)
        let taxAmount = sub_total * (tax_rate / 100)
        self.grand_total = (sub_total + tipAmount + taxAmount) //jan28 changed to reutnr to self instead of the general grand_total + got rid of division
        return grand_total
    }
}

func split_my_bill(bill: Bill) -> Double {
    bill.grand_total = bill.compute_price() //jan28 had to add to make sure price was being computed properly.
    var amount: Double = bill.grand_total / Double(bill.num_people)
    return amount
}

//jan28: added functionality here
func round_up(payment: Double) -> Int {
    return Int(ceil(payment)) //learned how to use ceil function here
}

//jan28: added functionality here
func remove_person(bill: Bill, cost_of_meal: Double) -> Void {
    bill.num_people -= 1;
    bill.sub_total -= cost_of_meal;
    bill.grand_total = bill.compute_price();
}

// jan29: added functionality here to output in a clean way
func print_clean(bill: Bill, name: String) -> Void
{
    bill.sub_total = Double(round_up(payment: bill.sub_total))
    bill.compute_price();
    print()
    print("This is the transaction labeled " + name + ".")
    print("---");
    print("Subtotal: " + String(bill.sub_total))
    print("+ Tax: " + String(bill.tax_rate/100 * bill.sub_total));
    print("+ Tip: " + String(bill.tip_percentage/100 * bill.sub_total));
    print("---------")
    print("Grand Total for " + String(bill.num_people) + " people is $" + String(bill.grand_total));
    print("Split for these people is approx. $" + String(ceil(split_my_bill(bill: bill)))) //jan29: modified to add rounding to keep things simple. was encountering a decimal places error.
}

//jan29: combined all helper functions into one
func do_everything(sub_total: Double, tip_percentage: Double, tax_rate: Double, num_people: Int, name: String)
{
    var bill = Bill(sub_total: sub_total, tip_percentage:tip_percentage, num_people: num_people, tax_rate: tax_rate);
    bill.compute_price()
    print_clean(bill: bill, name: name);
    print()
    print("Combined function done")
}

let bill_example: Bill = Bill(sub_total: 100, tip_percentage: 10, num_people: 5, tax_rate: 5)

split_my_bill(bill: bill_example)


//jan28: wrote these tests to make sure everything is working
let bill = Bill(sub_total: 100, tip_percentage: 10, num_people: 5, tax_rate: 5)

// Test compute_price function
print("Computed Price: \(bill.compute_price())") // Expected: 115.0

// Test split_my_bill function
print("Split Bill: \(split_my_bill(bill: bill))") // Expected: 23.0

// Test round_up function
print("Rounded Up: \(round_up(payment: 23.45))") // Expected: 24

// Test remove_person function
remove_person(bill: bill, cost_of_meal: 20)
print("Number of People After Removal: \(bill.num_people)") // Expected: 4
print("New Subtotal: \(bill.sub_total)") // Expected: 80.0
print("New Grand Total: \(bill.compute_price())") // Expected: 92.0

print()
print()
print()
print("CLEAN OUTPUT")
print_clean(bill: bill, name: "Pizza")

print()
do_everything(sub_total: 500, tip_percentage: 12, tax_rate: 7, num_people: 13, name: "WOOHOO")

