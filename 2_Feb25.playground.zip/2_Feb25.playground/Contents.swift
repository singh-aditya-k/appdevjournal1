// App Dev Journal: Tuesday, February 25. There is no actual coding for the first part of this week, so I will just copy the code from the page that I am visualizing here for good measure. Please collapse the code and look below it for a detailed explanation of what is going on.

// Today: GameView

//
//  GameView.swift
//  TicTacToev1
//
//  Created by Rajiv Mukherjee on 2/26/24.
//

import SwiftUI

struct GameView: View {
    
    @EnvironmentObject var game:GameService
    @Environment (\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack{
            VStack {
                //run an if check on the array of players and both are current then setboth as false
                if [game.player1.isCurrent, game.player2.isCurrent]
                    .allSatisfy({$0 == false}){
                        Text("Select a player to start")
                    }
                
                HStack{
                    Button(game.player1.name){
                        game.player1.isCurrent = true
                    }
                    .padding(8)
                    .background(RoundedRectangle(cornerRadius: 10)
                        .fill(game.player1.isCurrent ?    Color.green: Color.gray)
                    )
                    .foregroundColor(.white)
                    
                    Button(game.player2.name){
                        game.player2.isCurrent = true
                    }
                    .padding(8)
                    .background(RoundedRectangle(cornerRadius: 10)
                        .fill(game.player2.isCurrent ?    Color.green: Color.gray)
                    )
                    .foregroundColor(.white)
                    
                    
                }//end of HStack
                .disabled(game.gameStarted)
                
                //create game board here
                VStack{
                    HStack{
                        ForEach(0...2, id: \.self){
                            index in SquareView(index: index)
                        }
                    }
                    
                    HStack{
                        ForEach(3...5, id: \.self){
                            index in SquareView(index: index)
                        }
                    }
                    
                    HStack{
                        ForEach(6...8, id: \.self){
                            index in SquareView(index: index)
                        }
                    }
                }
                //
                .disabled(game.boardDisabled)
                //display winner when game is over
                VStack{
                    if game.gameOver {
                        Text("Game Over")
                        
                        if game.possibleMoves.isEmpty {
                            Text("Nobody wins")
                        } else {
                            Text("\(game.currentPlayer.name) wins!")
                        }
                        
                        Button("New Game") {
                            game.reset()
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
                .font(.largeTitle)
                Spacer()
                
            }.toolbar{
                ToolbarItem(placement: .topBarTrailing) {
                    Button("End Game"){
                        dismiss()
                    }.buttonStyle(.bordered)
                }
            }//end of toolbar
            .navigationTitle("Tic Tac Toe")
            .onAppear{
                game.reset()
            }
        }//end of navigation stack
    }
}

#Preview {
    GameView()
        .environmentObject(GameService())
}

/*
 The @EnvironmentObject is used to manage variables that will be used for the
 whole page. In this case, we come from GAMESERVICE and keep track of a singular game
 
 IF: if both players are currently "current", then set them both to false (usually for a peer game) and let the player pick which one is going to be the starting one
 
 HStack: this is the button array that makes the above possible. When one is clicked, that player will become the first player to be current and will start the alternation
 
 VStack + HStack: This is the gameboard here. Instead of a square picture, all we need is a 2D array loaded wtih (SQUAREVIEW) instances inside
 
 **Logic handled in GameSquare, see another day's journal**
 
 Disable + Win Condition: Once th board is full and the win conditions are satisfied, the board will be disabled and the buttons will no longer  be functional. The game will then be reset in GameSquare.
 */
