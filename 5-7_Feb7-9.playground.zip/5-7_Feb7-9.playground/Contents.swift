//Coding Journal Friday Feb 7 - Sunday Feb 9

/* GOALS
 
 F: Labeled (feb7) in the major comment block -- copy over tic tac toe code and change some logic
 Sa: Unlabeled, added functionality (everything unique that wasn't a test)
 Su: Labeled (feb9) Testing with help of GPT for coverage.

 */
import Foundation

struct board { //board copied from tic tac toe prep and modified for our use.
    var board: [[String]]
    init() {
        board = Array(repeating: Array(repeating: "_", count: 4), count: 4)
    }
    
    func printBoard() {
        for row in board {
            print(row)
        }
    }
    
    func isEmpty() -> Bool {
        for row in board {
            for cell in row {
                if cell == "_" {
                    return true
                }
            }
        }
        return false
    }
    
    func isValidMove(row: Int, col: Int) -> Bool { //used only for testing
        if row < 0 || row >= 4 || col < 0 || col >= 4 {
            return false
        }
        if board[row][col] == "_" {
            return true
        }
        return false
    }
}

//feb9: realized that my implementation did not meet the requirements for the game, so i am commenting it out and seeking the help of GPT. most will remain the same, but it's easier to go back and overwrite logic.
//struct FourQueensProblem { //also copied and modified
//    var currentBoard: board
//    var playerTurn: String //feb7 not really needed
//    
//    init() {
//        currentBoard = board()
//        playerTurn = "X"
//    }
//    
//    mutating func move(row: Int, col: Int) -> Bool { //feb4 added: must be mutating to allow it to change itself feb7 needed for limited uses | feb9 modified to reflect current usage
//        if currentBoard.isValidMove(row: row, col: col) {
//            currentBoard.board[row][col] = playerTurn
//            if(checkWin() == playerTurn) {print("WIN: \(playerTurn)"); return true;} //feb5 modified
//            return true
//        }
//        return false
//    }
//    
//    mutating func switchTurn() { //feb4 added to call inside the mutating func move feb7 not needed, but keeping in file
//        playerTurn = playerTurn == "X" ? "O" : "X" //feb4 syntax similar to if is x, then make it o, otherwise make it x
//    }
//    
//    mutating func reset() { //feb4 added function feb7 this will help, we just need to modify conditions
//        currentBoard = board()
//        playerTurn = "X" //let's just keep this default for right now
//    }
//    
//    
//    //feb4 added | feb7 we don't need this, but we can keep it for now | feb8 modified to check and make it work.
//    func checkWin() -> String? {
//        var queenCount: Int = 0
//        
//        for row in currentBoard.board {
//            for cell in row{
//                if cell == "X" {queenCount += 1;}
//        }
//            if queenCount > 1 {return "FAIL";}
//        }
//        print("WIN")
//        return "WIN"
//}
//}


//feb9 added
struct FourQueensProblem {
    var currentBoard: board
    
    init() {
        currentBoard = board()
    }
    
    mutating func placeQueen(row: Int, col: Int) -> Bool {
        if currentBoard.isValidMove(row: row, col: col) {
            currentBoard.board[row][col] = "Q"
            return true
        }
        return false
    }
    
    func isSolved() -> Bool {
        let queenPositions = getQueenPositions()
        
        if queenPositions.count != 4 {
            return false
        }
        
        for i in 0..<queenPositions.count {
            for j in (i+1)..<queenPositions.count {
                let (r1, c1) = queenPositions[i]
                let (r2, c2) = queenPositions[j]
                
                if r1 == r2 || c1 == c2 || abs(r1 - r2) == abs(c1 - c2) {
                    return false
                }
            }
        }
        
        return true
    }
    
    private func getQueenPositions() -> [(Int, Int)] {
        var positions: [(Int, Int)] = []
        for row in 0..<4 {
            for col in 0..<4 {
                if currentBoard.board[row][col] == "Q" {
                    positions.append((row, col))
                }
            }
        }
        return positions
    }
    
    mutating func reset() {
        currentBoard = board()
    }
}

//feb9 testing:
// Test the FourQueensProblem struct
print("Testing FourQueensProblem struct:")
var game = FourQueensProblem()

print("\nInitial empty board:")
game.currentBoard.printBoard()
print("Is solved? \(game.isSolved())")

print("\nPlacing queens:")
_ = game.placeQueen(row: 0, col: 1)
_ = game.placeQueen(row: 1, col: 3)
_ = game.placeQueen(row: 2, col: 0)
_ = game.placeQueen(row: 3, col: 2)
game.currentBoard.printBoard()
print("Is solved? \(game.isSolved())")

print("\nTesting invalid placement:")
game.reset()
_ = game.placeQueen(row: 0, col: 0)
_ = game.placeQueen(row: 0, col: 1)
game.currentBoard.printBoard()
print("Is solved? \(game.isSolved())")

print("\nTesting diagonal conflict:")
game.reset()
_ = game.placeQueen(row: 0, col: 0)
_ = game.placeQueen(row: 1, col: 1)
_ = game.placeQueen(row: 2, col: 2)
_ = game.placeQueen(row: 3, col: 3)
game.currentBoard.printBoard()
print("Is solved? \(game.isSolved())")

print("\nTesting valid solution:")
game.reset()
_ = game.placeQueen(row: 0, col: 1)
_ = game.placeQueen(row: 1, col: 3)
_ = game.placeQueen(row: 2, col: 0)
_ = game.placeQueen(row: 3, col: 2)
game.currentBoard.printBoard()
print("Is solved? \(game.isSolved())")

