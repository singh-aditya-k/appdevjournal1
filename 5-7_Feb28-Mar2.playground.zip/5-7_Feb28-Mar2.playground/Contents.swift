// Coding Journal -- Friday Feb 28 - Sun, Mar 2

/*
 F: Data structures and some basic functions
 S: Finish this implementation
 Su: Test everything
 */

//5. Music Playlist Manager
//Scenario: Create a simple music playlist management system.
//Data Structures:
//    1.    Struct `Song`: title, artist, duration, genre
//    2.    Class `Playlist`: name, songs
//    3.    Enum `Genre`: Pop, Rock, Jazz, Classical, HipHop, Other
//Functions:
//    1.    func addSong(song: Song) -> Void
//    2.    func removeSong(title: String) -> Bool
//    3.    func getTotalDuration() -> Double
//    4.    func getSongsByGenre(genre: Genre) -> Song
//    5.    func shufflePlaylist() -> Song


struct Song {
    let title: String
    let artist: String
    let duration: Double
    let genre: String
    var str: String?
    
    init(title: String, artist: String, duration: Double, genre: String) {
        self.title = title
        self.artist = artist
        self.duration = duration
        self.genre = genre
        self.str = "\(title) by \(artist)"
    }
    
    
}

class Playlist {
    var name: String
    var songs: [Song] = []
    
    init(name: String, songs: [Song]) {
        self.name = name
        self.songs = songs
    }
    
    func addSong(song: Song) {
        songs.append(song)
    }
    
    func removeSong(song1: Song)
    {
        var i: Int = 0;
        for song in songs{
            if(song1.title == song.title)
            {songs.remove(at: i)}
            i+=1
        }
    }
    
    func getTotalDuration() -> Double {
        var totalDuration: Double = 0
        for song in songs {
            totalDuration += song.duration
        }
        return totalDuration
    }
    
    func getSongsByGenre(genre: String) -> [Song] {
        var songsByGenre: [Song] = []
        for song in songs {
            if song.genre == genre {
                songsByGenre.append(song)
            }
        }
        return songsByGenre
    }
    
    func shufflePlayList() -> Song {
        let randomIndex = Int.random(in: 0..<songs.count)
        return songs[randomIndex]
    }
}

enum Genre: String {
    case pop = "Pop"
    case rock = "Rock"
    case jazz = "Jazz"
    case classical = "Classical"
    case hipHop = "HipHop"
    case other = "Other"
}

// ... (Your existing code remains unchanged)

// Create some test songs
let song1 = Song(title: "Bohemian Rhapsody", artist: "Queen", duration: 354.0, genre: Genre.rock.rawValue)
let song2 = Song(title: "Stairway to Heaven", artist: "Led Zeppelin", duration: 482.0, genre: Genre.rock.rawValue)
let song3 = Song(title: "Billie Jean", artist: "Michael Jackson", duration: 294.0, genre: Genre.pop.rawValue)

// Create a playlist
let myPlaylist = Playlist(name: "My Favorite Songs", songs: [])

// Test addSong
print("Testing addSong:")
myPlaylist.addSong(song: song1)
myPlaylist.addSong(song: song2)
myPlaylist.addSong(song: song3)
print("Playlist now has \(myPlaylist.songs.count) songs")

// Test getTotalDuration
print("\nTesting getTotalDuration:")
let totalDuration = myPlaylist.getTotalDuration()
print("Total duration: \(totalDuration) seconds")

// Test getSongsByGenre
print("\nTesting getSongsByGenre:")
let rockSongs = myPlaylist.getSongsByGenre(genre: Genre.rock.rawValue)
print("Rock songs: \(rockSongs.map { $0.title }.joined(separator: ", "))")

// Test shufflePlayList
print("\nTesting shufflePlayList:")
let randomSong = myPlaylist.shufflePlayList()
print("Random song: \(randomSong.title)")

// Test removeSong
print("\nTesting removeSong:")
myPlaylist.removeSong(song1: song2)
print("Playlist now has \(myPlaylist.songs.count) songs")
print("Remaining songs: \(myPlaylist.songs.map { $0.title }.joined(separator: ", "))")

// Test edge cases
print("\nTesting edge cases:")
let emptySongList = myPlaylist.getSongsByGenre(genre: "Country")
print("Songs in Country genre: \(emptySongList.count)")

let emptyPlaylist = Playlist(name: "Empty Playlist", songs: [])
let totalDurationEmpty = emptyPlaylist.getTotalDuration()
print("Duration of empty playlist: \(totalDurationEmpty)")

// Attempt to remove a song that doesn't exist
let nonexistentSong = Song(title: "Nonexistent Song", artist: "Unknown", duration: 0, genre: "Unknown")
myPlaylist.removeSong(song1: nonexistentSong)
print("Playlist still has \(myPlaylist.songs.count) songs after attempting to remove nonexistent song")
