// App Dev Journal: Thursday, Feb 27. There is no actual coding for the first part of this week, so I will just copy the code from the page that I am visualizing here for good measure. Please collapse the code and look below it for a detailed explanation of what is going on.

// Today: GameSquare, SquareView, AppEntry, Debrief

//
//  TicTacToev1App.swift
//  TicTacToev1
//
//  Created by Rajiv Mukherjee on 2/19/24.
//

import SwiftUI

@main
struct AppEntry: App {
    
    @StateObject var game = GameService() //create an instance of the class
    
    
    var body: some Scene {
        WindowGroup {
            StartView()
                .environmentObject(game)
        }
    }
}


//
//  GameSquare.swift
//  TicTacToev1
//
//  Created by Rajiv Mukherjee on 3/4/24.
//

import SwiftUI

struct GameSquare{
    var id:Int //whiich tile 1 to 9
    var player: Player? //? means value can be nil
    
    var image:Image{
        //the line below is not checking for equality.
        //it is only testing for the existence of value within an optional
        
        if let player = player {
            return player.gamePiece.image
        }
        else {
            return Image("none")
        }
    }
    
    static var reset:[GameSquare]{
        var squares = [GameSquare]()
            for index in 1...9 {
                squares.append(GameSquare(id: index))
            }
            return squares
            
        
    }
}


//
//  SquareView.swift
//  TicTacToev1
//
//  Created by Rajiv Mukherjee on 3/4/24.
//

import SwiftUI

struct SquareView: View {
    
    @EnvironmentObject var game: GameService
    let index: Int
    
    var body: some View {
        Button{
            game.makeMove(at: index)
        } label: {
            game.gameBoard[index].image
                .resizable()
                .frame(width:100, height:100)
        }
        .disabled(game.gameBoard[index].player != nil)
        .buttonStyle(.bordered)
        .foregroundColor(.primary)
    }
}

#Preview {
    //index set to 1 just for previewing 1 tile
    SquareView(index: 1)
        .environmentObject(GameService())
}


/*
 APPENTRY:
    very simple logic here: just creates a state var of a gameservice to allow the logic to pass and opens the startview to generate the initial UI
 
 GAMESQUARE:
    also very simple logic/struct for the details of what needs to be contained within the square in the first place. also contains reset logic
 
 SQUAREVIEW:
    also depends on a GameService var and lets us preview one tile if we so choose to
 
 Overall:
 
 StartView introduces the user to the game and allows for setup
 GameView provides the UI that underlies the entire game
 GameService provides the vast majority of the logic for the entire game and makes the game run
 AppEntry helps start the game with StartView
 GameSquare handles individual square operatiosn
 SquareView shows you an individual square and can reset it.
 */
