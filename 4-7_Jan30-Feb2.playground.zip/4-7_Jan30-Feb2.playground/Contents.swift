// Coding Journal: Thursday Jan 30 - Sun Feb 2

/* GOALS
 
 Th: Unlabeled, set everything up
 F: Labeled //jan31, add more functions
 Sa: Labeled, add more functions and debug existing ones
 Su: Labeled, test the code (used GPT to ensure proper coverage) and added some comments
 */


class MakeModelYear {
    var name: String
    var year: Int
    var make: String
    var model: String
    
    init(name: String, year: Int, make: String, model: String) {
        self.name = name
        self.year = year
        self.make = make
        self.model = model
    }
    
    func print_clean() -> Void {
        print("\(make) \(model) (\(year))") // \ notation for printing -- works similarly to python
    }
    
    // potential for additional functionality here: create a map with car sizes linked to score values to calculate a score
}

class Carmax_Desc: MakeModelYear {
    var mileage: Int
    var transmission: String //feb2 manual or automatic
    var engine: String //feb2 v6, v8, etc
    var color: String
    var price: Double
    var current_owner: String? //setting to nil because we can't really be sure whether there is a current owner. some cars can potentially be sold new
    var num_owners: Int
    var defects: Bool //feb2 scratches, dents, anything basic
    var major_defects: Bool //feb2: flood damage, missing or non-functional lights, etc.
    
    init(name: String, year: Int, make: String, model: String, mileage: Int, transmission: String, engine: String, color: String, price: Double, num_owners: Int, defects: Bool, major_defects: Bool) {
        self.mileage = mileage
        self.transmission = transmission
        self.engine = engine
        self.color = color
        self.price = price
        self.num_owners = num_owners
        self.defects = defects
        self.major_defects = major_defects
        
        super.init(name: name, year: year, make: make, model: model)
        
        self.current_owner = nil // good practices here!
    }
    
    //updated jan31
    override func print_clean() -> Void {
        print("\(make) \(model) (\(year)), \(transmission) IN \(color) : \(price)")
        print("Miles: " + String(mileage))
        print("Defects: \(defects), Major Defects: \(major_defects)")
        print(num_owners == 1 ? "New Car" : "\(num_owners) Owners") //inline if statement here
    }
}

//created and added functionality jan31 -- returns TRUE if <score_bound> parameters are met
func user_prefs_basic(carmax_desc: Carmax_Desc, max_miles: Int, make: String, model: String, min_year: Int, transmission: String, color: String, score_bound: Int) -> Bool {
    var score: Int = 0;
    if carmax_desc.mileage < max_miles {
        score += 1
    }
    if carmax_desc.make == make {
        score += 1
    }
    if carmax_desc.model == model {
        score += 1
    }
    if carmax_desc.year >= min_year {
        score += 1
    }
    if carmax_desc.transmission == transmission {
        score += 1
    }
    if carmax_desc.color == color {
        score += 1
    }
    
    
    return score >= score_bound
}
//created and added functionality on jan31, debugged feb1, adding comments feb2
func user_prefs_full(carmax_desc: Carmax_Desc, max_miles: Int, make: String, model: String, min_year: Int, transmission: String, color: String, score_bound: Int, defect_count: Int, major_defect_count: Int) -> Bool {
    var score: Int = 0;
    if carmax_desc.mileage < max_miles {
        score += 1
    }
    if carmax_desc.make == make {
        score += 1
    }
    if carmax_desc.model == model {
        score += 1
    }
    if carmax_desc.year >= min_year {
        score += 1
    }
    if carmax_desc.transmission == transmission {
        score += 1
    }
    if carmax_desc.color == color {
        score += 1
    }
    if !carmax_desc.defects {
        score += 1
    }
    if !carmax_desc.major_defects {
        score += 1
    }
    
    
    return score >= score_bound
}

// Create instances of MakeModelYear
let car1 = MakeModelYear(name: "Sedan1", year: 2022, make: "Toyota", model: "Camry")
let car2 = MakeModelYear(name: "SUV1", year: 2023, make: "Honda", model: "CR-V")

// Test print_clean() for MakeModelYear
print("Testing MakeModelYear print_clean():")
car1.print_clean()
car2.print_clean()
print()

// Create instances of Carmax_Desc
let carmax1_this = Carmax_Desc(name: "Luxury1", year: 2021, make: "BMW", model: "3 Series", mileage: 15000, transmission: "Automatic", engine: "2.0L 4-cylinder", color: "Black", price: 35000.0, num_owners: 1, defects: false, major_defects: false)
let carmax2_this = Carmax_Desc(name: "Truck1", year: 2020, make: "Ford", model: "F-150", mileage: 30000, transmission: "Manual", engine: "3.5L V6", color: "Red", price: 40000.0, num_owners: 2, defects: true, major_defects: false)

// Test print_clean() for Carmax_Desc
print("Testing Carmax_Desc print_clean():")
carmax1_this.print_clean()
print()
carmax2_this.print_clean()
print()

// Test user_prefs_basic function -- feb1 had to debug this
print("Testing user_prefs_basic function:")
let basicPref1 = user_prefs_basic(carmax_desc: carmax1_this, max_miles: 20000, make: "BMW", model: "3 Series", min_year: 2020, transmission: "Automatic", color: "Black", score_bound: 5)
print("Basic preference match for carmax1: \(basicPref1)")

let basicPref2 = user_prefs_basic(carmax_desc: carmax2_this, max_miles: 35000, make: "Ford", model: "F-150", min_year: 2019, transmission: "Automatic", color: "Blue", score_bound: 4)
print("Basic preference match for carmax2: \(basicPref2)")
print()


// Test user_prefs_full function -- feb1 had to debug this
print("Testing user_prefs_full function:")
let fullPref1 = user_prefs_full(carmax_desc: carmax1_this, max_miles: 20000, make: "BMW", model: "3 Series", min_year: 2020, transmission: "Automatic", color: "Black", score_bound: 7, defect_count: 0, major_defect_count: 0)
print("Full preference match for carmax1: \(fullPref1)")

let fullPref2 = user_prefs_full(carmax_desc: carmax2_this, max_miles: 35000, make: "Ford", model: "F-150", min_year: 2019, transmission: "Manual", color: "Red", score_bound: 6, defect_count: 1, major_defect_count: 0)
print("Full preference match for carmax2: \(fullPref2)")







// Existing car instances
let carmax1 = Carmax_Desc(name: "Luxury1", year: 2021, make: "BMW", model: "3 Series", mileage: 15000, transmission: "Automatic", engine: "2.0L 4-cylinder", color: "Black", price: 35000.0, num_owners: 1, defects: false, major_defects: false)
let carmax2 = Carmax_Desc(name: "Truck1", year: 2020, make: "Ford", model: "F-150", mileage: 30000, transmission: "Manual", engine: "3.5L V6", color: "Red", price: 40000.0, num_owners: 2, defects: true, major_defects: false)

// New car instances that will fail some preferences
let carmax3 = Carmax_Desc(name: "Economy1", year: 2018, make: "Toyota", model: "Corolla", mileage: 50000, transmission: "Automatic", engine: "1.8L 4-cylinder", color: "White", price: 18000.0, num_owners: 3, defects: true, major_defects: true)
let carmax4 = Carmax_Desc(name: "Sports1", year: 2022, make: "Mazda", model: "MX-5", mileage: 5000, transmission: "Manual", engine: "2.0L 4-cylinder", color: "Blue", price: 30000.0, num_owners: 1, defects: false, major_defects: false)

print("Testing user_prefs_basic function with failing cases:")

// Case 1: Fails due to high mileage and wrong make
let basicPref3 = user_prefs_basic(carmax_desc: carmax3, max_miles: 40000, make: "Honda", model: "Civic", min_year: 2019, transmission: "Automatic", color: "White", score_bound: 4)
print("Basic preference match for carmax3: \(basicPref3)")

// Case 2: Fails due to wrong transmission and color
let basicPref4 = user_prefs_basic(carmax_desc: carmax4, max_miles: 10000, make: "Mazda", model: "MX-5", min_year: 2021, transmission: "Automatic", color: "Red", score_bound: 5)
print("Basic preference match for carmax4: \(basicPref4)")

print("\nTesting user_prefs_full function with failing cases:")

// Case 1: Fails due to older year, defects, and major defects
let fullPref3 = user_prefs_full(carmax_desc: carmax3, max_miles: 60000, make: "Toyota", model: "Corolla", min_year: 2020, transmission: "Automatic", color: "White", score_bound: 6, defect_count: 0, major_defect_count: 0)
print("Full preference match for carmax3: \(fullPref3)")

// Case 2: Fails due to wrong make, model, and transmission, despite meeting other criteria
let fullPref4 = user_prefs_full(carmax_desc: carmax4, max_miles: 10000, make: "Honda", model: "S2000", min_year: 2020, transmission: "Automatic", color: "Blue", score_bound: 6, defect_count: 0, major_defect_count: 0)
print("Full preference match for carmax4: \(fullPref4)")

// Additional test cases to demonstrate score_bound impact
print("\nTesting with different score_bound values:")

let basicPref5 = user_prefs_basic(carmax_desc: carmax4, max_miles: 10000, make: "Mazda", model: "MX-5", min_year: 2021, transmission: "Manual", color: "Blue", score_bound: 6)
print("Basic preference match for carmax4 (high score_bound): \(basicPref5)")

let basicPref6 = user_prefs_basic(carmax_desc: carmax4, max_miles: 10000, make: "Mazda", model: "MX-5", min_year: 2021, transmission: "Manual", color: "Blue", score_bound: 4)
print("Basic preference match for carmax4 (lower score_bound): \(basicPref6)")
