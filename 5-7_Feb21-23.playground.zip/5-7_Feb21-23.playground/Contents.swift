// Coding Journal Fri Feb 21 - Sun Feb 23
// Goals: See below


//All New Scenario


//2. Library Management System
//Scenario: Create a library management system to track books, members, and loans.
//Data Structures:
//    1.    Struct `Book`: isbn, title, author, year, available //done feb21
//    2.    Class `Member`: id, name, borrowedBooks //done feb21
//    3.    Enum `LoanStatus`: Active, Overdue, Returned //done feb22
//Functions:
//    1.    func addBook(book: Book) -> Void //done feb21, fixed feb22
//    2.    func borrowBook(memberId: String, isbn: String) -> Bool //done feb21, fixed feb22
//    3.    func returnBook(isbn: String) -> Bool //done feb22
//    4.    func searchBooks(query: String) -> Book //done feb22

// Tests: done feb23

class Book { //changed to a class to make it mutable
    let isbn: String //we can use let here because we're probably not going to change these...ever.
    let serialNo: String
    let title: String
    let author: String
    let year: Int
    var isAvailable: Bool
    
    init(isbn: String, serialNo: String, title: String, author: String, year: Int, isAvailable: Bool) {
        self.isbn = isbn
        self.serialNo = serialNo
        self.title = title
        self.author = author
        self.year = year
        self.isAvailable = isAvailable
    }
    
    func details() -> String { "\(isbn): \(title), \(author)"}
}

class Member {
    let id: String
    var name: String
    var borrowedBooks: [String]
    var countBorrowedBooks: Int
    
    init(id: String, name: String, borrowedBooks: [String], cbb: Int) {
        self.id = id
        self.name = name
        self.borrowedBooks = borrowedBooks
        self.countBorrowedBooks = cbb
    }
    
    func addBook(book: Book)
    {
        self.borrowedBooks.append(book.details()); countBorrowedBooks+=1;
        book.isAvailable = false
    }
    
    func returnBook(book: Book) -> Bool
    {
        guard let index = self.borrowedBooks.firstIndex(where: { $0.contains(book.isbn) }) else { return false }
        borrowedBooks.remove(at: index)
        countBorrowedBooks-=1;
        return true;
    }
    
    func searchInBorrowedBooks(query: String) -> Bool
    {
        for book in borrowedBooks {
            if book.contains(query) {
                return true
            }
        }
        return false
    }
    
    func getOverdueLoans() -> (Member, Book) {
        fatalError("Not implemented")
    }
}


enum LoanStatus {
    case active;
    case overdue;
    case returned;
}

// Create some books
let book1 = Book(isbn: "123", serialNo: "A1", title: "Swift Programming", author: "John Doe", year: 2021, isAvailable: true)
let book2 = Book(isbn: "456", serialNo: "B2", title: "iOS Development", author: "Jane Smith", year: 2022, isAvailable: true)
let book3 = Book(isbn: "789", serialNo: "C3", title: "Algorithms", author: "Alice Johnson", year: 2020, isAvailable: true)

// Create some members
let member1 = Member(id: "M1", name: "Bob", borrowedBooks: [], cbb: 0)
let member2 = Member(id: "M2", name: "Carol", borrowedBooks: [], cbb: 0)

// Test adding books to members
print("Testing adding books to members:")
member1.addBook(book: book1)
member2.addBook(book: book2)
print("Member 1 borrowed books: \(member1.borrowedBooks)")
print("Member 2 borrowed books: \(member2.borrowedBooks)")
print("Book 1 availability: \(book1.isAvailable)")
print("Book 2 availability: \(book2.isAvailable)")

// Test returning books
print("\nTesting returning books:")
let returnSuccess1 = member1.returnBook(book: book1)
let returnSuccess2 = member2.returnBook(book: book2)
print("Return success for member 1: \(returnSuccess1)")
print("Return success for member 2: \(returnSuccess2)")
print("Member 1 borrowed books after return: \(member1.borrowedBooks)")
print("Member 2 borrowed books after return: \(member2.borrowedBooks)")
print("Book 1 availability after return: \(book1.isAvailable)")
print("Book 2 availability after return: \(book2.isAvailable)")

// Test searching in borrowed books
print("\nTesting searching in borrowed books:")
member1.addBook(book: book3)
let searchResult1 = member1.searchInBorrowedBooks(query: "Algorithms")
let searchResult2 = member1.searchInBorrowedBooks(query: "Python")
print("Search for 'Algorithms' in member 1's books: \(searchResult1)")
print("Search for 'Python' in member 1's books: \(searchResult2)")

// Test book details
print("\nTesting book details:")
print(book1.details())
print(book2.details())
print(book3.details())

// Test member borrowed book count
print("\nTesting member borrowed book count:")
print("Member 1 borrowed book count: \(member1.countBorrowedBooks)")
print("Member 2 borrowed book count: \(member2.countBorrowedBooks)")


